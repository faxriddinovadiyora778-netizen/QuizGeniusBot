# Quiz Genius Bot

## Ishga tushirish

### 1. Kutubxonalarni o'rnatish
```
pip install -r requirements.txt
```

### 2. Botni ishga tushirish
```
python bot.py
```

### 3. Render.com da joylash
1. github.com ga kod yuklang
2. render.com da yangi "Background Worker" yarating
3. requirements.txt avtomatik o'rnatiladi
4. Ishga tushadi!

## Sozlash (bot.py ichida)
- ADMIN_USERNAME — sizning Telegram username
- ADMIN_CHAT_ID — sizning Telegram ID
- CHANNELS — kanal ma'lumotlari
